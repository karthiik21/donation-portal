package com.smartdonation.servlet;

import com.smartdonation.dao.UserDAO;
import com.smartdonation.model.User;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        UserDAO dao = new UserDAO();
        User u = dao.login(email, password);

        if (u != null) {
            HttpSession session = req.getSession();
            session.setAttribute("user", u);
            res.sendRedirect("dashboard.jsp");
        } else {
            res.sendRedirect("error.jsp");
        }
    }
}
