package com.smartdonation.dao;
import java.sql.*;

public class DBConnection {
    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:8080/smartdonation3", "root", ""
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }
}
